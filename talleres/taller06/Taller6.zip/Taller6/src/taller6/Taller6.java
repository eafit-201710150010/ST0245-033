/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller6;

import java.util.ArrayList;

/**
 *
 * @author ljpalaciom
 */
public class Taller6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MiArrayList list = new MiArrayList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        try {
             System.out.println(list.get(1));
             list.add(2,5);
             list.add(6);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(list.size());
        System.out.println(list);
    }
}
